
const express=require('express');
const cors=require('cors');
const bodyParser=require('body-parser');
const app=express();
app.use(cors());
app.use(bodyParser.json());

let users=[];
let complaints=[];

app.post('/api/register',(req,res)=>{
 const user={id:Date.now(),...req.body};
 users.push(user);
 res.json(user);
});

app.post('/api/login',(req,res)=>{
 const user=users.find(u=>u.email===req.body.email && u.password===req.body.password);
 if(!user) return res.status(401).json({error:'Invalid'});
 res.json(user);
});

app.get('/api/complaints',(req,res)=>res.json(complaints));

app.post('/api/complaints',(req,res)=>{
 const complaint={id:Date.now(),status:'Received',date:new Date().toLocaleString(),...req.body};
 complaints.push(complaint);
 res.json(complaint);
});

app.listen(5000,()=>console.log('Server running on 5000'));
