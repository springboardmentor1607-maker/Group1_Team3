
import React,{useEffect,useState} from "react";
export default function Complaints(){
 const[data,setData]=useState([]);
 useEffect(()=>{fetch("http://localhost:5000/api/complaints").then(r=>r.json()).then(setData)},[]);
 return(<div className="container"><h2>Complaints List</h2>
 {data.map(c=><div className="card" key={c.id}>
 <b>{c.title}</b><p>{c.description}</p><small>Status: {c.status}</small><br/><small>{c.date}</small>
 </div>)}
 </div>);
}
