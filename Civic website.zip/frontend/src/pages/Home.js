
import React from "react";
export default function Home(){return <div className="container"><h1>CleanStreet Civic Platform</h1><p>Report civic issues, track progress, and improve your community.</p><div class='card'>✔ Easy reporting</div><div class='card'>✔ Real-time tracking</div></div>;}