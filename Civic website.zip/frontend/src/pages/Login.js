
import React,{useState} from "react";
export default function Login(){
 const[email,setEmail]=useState("");const[password,setPassword]=useState("");
 const login=()=>fetch("http://localhost:5000/api/login",{method:"POST",headers:{'Content-Type':'application/json'},
 body:JSON.stringify({email,password})}).then(()=>alert("Logged in"));
 return(<div className="container"><h2>Login</h2>
 <input placeholder="Email" onChange={e=>setEmail(e.target.value)}/>
 <input placeholder="Password" onChange={e=>setPassword(e.target.value)}/>
 <button onClick={login}>Login</button></div>);
}
