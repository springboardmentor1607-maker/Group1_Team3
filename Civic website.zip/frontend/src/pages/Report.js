
import React,{useState} from "react";
export default function Report(){
 const[title,setTitle]=useState("");const[description,setDescription]=useState("");
 const submit=()=>fetch("http://localhost:5000/api/complaints",{method:"POST",headers:{'Content-Type':'application/json'},
 body:JSON.stringify({title,description})}).then(()=>alert("Complaint submitted"));
 return(<div className="container"><h2>Report Issue</h2>
 <input placeholder="Title" onChange={e=>setTitle(e.target.value)}/>
 <textarea placeholder="Description" onChange={e=>setDescription(e.target.value)}/>
 <button onClick={submit}>Submit</button></div>);
}
