
import React from "react";
export default function About(){return <div className="container"><h2>About Project</h2><p>CleanStreet is designed to help citizens communicate issues directly to authorities and ensure transparency.</p></div>;}