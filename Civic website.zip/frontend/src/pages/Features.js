
import React from "react";
export default function Features(){return <div className="container"><h2>Key Features</h2><ul><li>Issue reporting</li><li>Status tracking</li><li>Community collaboration</li></ul></div>;}