
import React from "react";
export default function Dashboard(){return <div className="container"><h2>User Dashboard</h2><p>Here you can manage your activity and monitor complaints.</p></div>;}