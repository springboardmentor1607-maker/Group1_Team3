
import React from "react";
import {BrowserRouter as Router,Routes,Route,Link} from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Features from "./pages/Features";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Report from "./pages/Report";
import Complaints from "./pages/Complaints";
import Contact from "./pages/Contact";
import "./App.css";

export default function App(){
 return(
  <Router>
   <nav className="nav">
    <Link to="/">Home</Link>
    <Link to="/about">About</Link>
    <Link to="/features">Features</Link>
    <Link to="/dashboard">Dashboard</Link>
    <Link to="/report">Report</Link>
    <Link to="/complaints">Complaints</Link>
    <Link to="/contact">Contact</Link>
    <Link to="/login">Login</Link>
    <Link to="/register">Register</Link>
   </nav>

   <Routes>
    <Route path="/" element={<Home/>}/>
    <Route path="/about" element={<About/>}/>
    <Route path="/features" element={<Features/>}/>
    <Route path="/dashboard" element={<Dashboard/>}/>
    <Route path="/report" element={<Report/>}/>
    <Route path="/complaints" element={<Complaints/>}/>
    <Route path="/contact" element={<Contact/>}/>
    <Route path="/login" element={<Login/>}/>
    <Route path="/register" element={<Register/>}/>
   </Routes>
  </Router>
 );
}
